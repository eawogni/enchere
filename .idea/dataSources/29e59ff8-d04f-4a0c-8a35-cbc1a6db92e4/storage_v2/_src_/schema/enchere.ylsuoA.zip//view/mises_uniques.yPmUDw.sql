create definer = root@localhost view mises_uniques as
select `enchere`.`mise`.`idMise`      AS `idMise`,
       `enchere`.`mise`.`montantMise` AS `montantMise`,
       `enchere`.`mise`.`login`       AS `login`,
       `enchere`.`mise`.`idEnchere`   AS `idEnchere`
from `enchere`.`mise`
group by `enchere`.`mise`.`montantMise`
having (count(`enchere`.`mise`.`montantMise`) = 1);

