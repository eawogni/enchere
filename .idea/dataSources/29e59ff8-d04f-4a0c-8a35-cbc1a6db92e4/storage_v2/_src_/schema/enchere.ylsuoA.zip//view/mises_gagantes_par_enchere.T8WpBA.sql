create definer = root@localhost view mises_gagantes_par_enchere as
select `mises`.`idMise`      AS `idMise`,
       `mises`.`login`       AS `login`,
       `mises`.`idEnchere`   AS `idEnchere`,
       `mises`.`montantMise` AS `montantMise`
from (select `mises_uniques`.`idMise`           AS `idMise`,
             `mises_uniques`.`login`            AS `login`,
             `mises_uniques`.`idEnchere`        AS `idEnchere`,
             `mises_uniques`.`montantMise`      AS `montantMise`,
             min(`mises_uniques`.`montantMise`) AS `MIN(montantMise)`
      from `enchere`.`mises_uniques`
      group by `mises_uniques`.`idEnchere`) `mises`;

