create definer = root@localhost view mises_multiples as
select `enchere`.`mise`.`idMise`      AS `idMise`,
       `enchere`.`mise`.`montantMise` AS `montantMise`,
       `enchere`.`mise`.`login`       AS `login`,
       `enchere`.`mise`.`idEnchere`   AS `idEnchere`
from `enchere`.`mise`
where (not (`enchere`.`mise`.`idMise` in (select `mises_uniques`.`idMise` from `enchere`.`mises_uniques`)));

